// Base de Datos de Comidas Completa
export const mealsDatabase = {
  desayuno: [
    {
      id: 'breakfast_1',
      name: 'Huevos con Pan Tostado',
      category: 'Desayuno',
      calories: 350,
      protein: 18,
      carbs: 35,
      fat: 12,
      fiber: 4,
      description: '2 huevos + 2 rebanadas de pan integral',
      ingredients: ['Huevos', 'Pan integral', 'Mantequilla'],
      prepTime: 10,
      nutrients: {
        calcio: '80mg',
        hierro: '3.5mg',
        vitaminaA: '650IU',
        vitaminaC: '0mg'
      }
    },
    {
      id: 'breakfast_2',
      name: 'Avena con Frutas',
      category: 'Desayuno',
      calories: 320,
      protein: 10,
      carbs: 55,
      fat: 8,
      fiber: 6,
      description: 'Taza de avena con plátano y arándanos',
      ingredients: ['Avena', 'Plátano', 'Arándanos', 'Leche'],
      prepTime: 5,
      nutrients: {
        calcio: '200mg',
        hierro: '2.1mg',
        vitaminaA: '15IU',
        vitaminaC: '12mg'
      }
    },
    {
      id: 'breakfast_3',
      name: 'Yogur con Granola',
      category: 'Desayuno',
      calories: 380,
      protein: 15,
      carbs: 52,
      fat: 10,
      fiber: 5,
      description: 'Yogur griego + granola + miel',
      ingredients: ['Yogur griego', 'Granola', 'Miel', 'Frutos secos'],
      prepTime: 3,
      nutrients: {
        calcio: '220mg',
        hierro: '1.8mg',
        vitaminaA: '450IU',
        vitaminaC: '8mg'
      }
    },
    {
      id: 'breakfast_4',
      name: 'Pancakes Proteicos',
      category: 'Desayuno',
      calories: 400,
      protein: 22,
      carbs: 45,
      fat: 11,
      fiber: 3,
      description: '2 pancakes con proteína + sirope',
      ingredients: ['Harina', 'Huevo', 'Proteína', 'Leche'],
      prepTime: 15,
      nutrients: {
        calcio: '150mg',
        hierro: '2.5mg',
        vitaminaA: '520IU',
        vitaminaC: '4mg'
      }
    },
    {
      id: 'breakfast_5',
      name: 'Batido de Proteína',
      category: 'Desayuno',
      calories: 280,
      protein: 30,
      carbs: 35,
      fat: 5,
      fiber: 2,
      description: 'Proteína + plátano + leche + almendras',
      ingredients: ['Proteína en polvo', 'Plátano', 'Leche', 'Almendras'],
      prepTime: 2,
      nutrients: {
        calcio: '300mg',
        hierro: '1.2mg',
        vitaminaA: '300IU',
        vitaminaC: '10mg'
      }
    },
    {
      id: 'breakfast_6',
      name: 'Omeleta Vegetariana',
      category: 'Desayuno',
      calories: 320,
      protein: 20,
      carbs: 28,
      fat: 14,
      fiber: 3,
      description: 'Omeleta con verduras y queso',
      ingredients: ['Huevos', 'Espinaca', 'Tomate', 'Queso', 'Cebolla'],
      prepTime: 12,
      nutrients: {
        calcio: '250mg',
        hierro: '3.2mg',
        vitaminaA: '2800IU',
        vitaminaC: '15mg'
      }
    }
  ],

  almuerzo: [
    {
      id: 'lunch_1',
      name: 'Pechuga de Pollo con Arroz',
      category: 'Almuerzo',
      calories: 580,
      protein: 45,
      carbs: 65,
      fat: 8,
      fiber: 2,
      description: '200g pechuga + taza de arroz integral + verduras',
      ingredients: ['Pechuga de pollo', 'Arroz integral', 'Brócoli', 'Zanahorias'],
      prepTime: 25,
      nutrients: {
        calcio: '35mg',
        hierro: '1.5mg',
        vitaminaA: '3500IU',
        vitaminaC: '35mg'
      }
    },
    {
      id: 'lunch_2',
      name: 'Salmón con Batata',
      category: 'Almuerzo',
      calories: 620,
      protein: 42,
      carbs: 58,
      fat: 18,
      fiber: 3,
      description: '200g salmón + batata + ensalada',
      ingredients: ['Salmón', 'Batata', 'Lechuga', 'Tomate', 'Aceite de oliva'],
      prepTime: 20,
      nutrients: {
        calcio: '25mg',
        hierro: '0.8mg',
        vitaminaA: '8500IU',
        vitaminaC: '28mg'
      }
    },
    {
      id: 'lunch_3',
      name: 'Carne Magra con Papas',
      category: 'Almuerzo',
      calories: 640,
      protein: 50,
      carbs: 60,
      fat: 14,
      fiber: 4,
      description: '200g carne magra + papas cocidas + verduras',
      ingredients: ['Carne magra', 'Papas', 'Espárragos', 'Cebolla'],
      prepTime: 30,
      nutrients: {
        calcio: '30mg',
        hierro: '3.5mg',
        vitaminaA: '1200IU',
        vitaminaC: '25mg'
      }
    },
    {
      id: 'lunch_4',
      name: 'Atún con Pasta Integral',
      category: 'Almuerzo',
      calories: 520,
      protein: 38,
      carbs: 65,
      fat: 9,
      fiber: 5,
      description: 'Lata de atún + pasta integral + tomate',
      ingredients: ['Atún enlatado', 'Pasta integral', 'Tomate', 'Aceitunas'],
      prepTime: 15,
      nutrients: {
        calcio: '15mg',
        hierro: '2.2mg',
        vitaminaA: '500IU',
        vitaminaC: '12mg'
      }
    },
    {
      id: 'lunch_5',
      name: 'Pollo con Quinoa',
      category: 'Almuerzo',
      calories: 580,
      protein: 44,
      carbs: 62,
      fat: 10,
      fiber: 6,
      description: '180g pollo + taza de quinoa + vegetales',
      ingredients: ['Pollo', 'Quinoa', 'Pimiento', 'Cebolla', 'Espinaca'],
      prepTime: 25,
      nutrients: {
        calcio: '45mg',
        hierro: '3.8mg',
        vitaminaA: '2200IU',
        vitaminaC: '42mg'
      }
    },
    {
      id: 'lunch_6',
      name: 'Pavo con Camote',
      category: 'Almuerzo',
      calories: 560,
      protein: 46,
      carbs: 58,
      fat: 9,
      fiber: 5,
      description: '180g pavo + camote asado + brócoli',
      ingredients: ['Pavo', 'Camote', 'Brócoli', 'Ajo'],
      prepTime: 28,
      nutrients: {
        calcio: '28mg',
        hierro: '2.1mg',
        vitaminaA: '12500IU',
        vitaminaC: '55mg'
      }
    },
    {
      id: 'lunch_7',
      name: 'Lentejas con Vegetales',
      category: 'Almuerzo',
      calories: 480,
      protein: 22,
      carbs: 68,
      fat: 8,
      fiber: 10,
      description: 'Taza de lentejas cocidas + zanahoria + cebolla',
      ingredients: ['Lentejas', 'Zanahoria', 'Cebolla', 'Tomate', 'Ajo'],
      prepTime: 35,
      nutrients: {
        calcio: '55mg',
        hierro: '6.5mg',
        vitaminaA: '4200IU',
        vitaminaC: '18mg'
      }
    }
  ],

  cena: [
    {
      id: 'dinner_1',
      name: 'Pechuga de Pollo Ligera',
      category: 'Cena',
      calories: 420,
      protein: 48,
      carbs: 35,
      fat: 8,
      fiber: 4,
      description: '200g pechuga + verduras cocidas',
      ingredients: ['Pechuga de pollo', 'Zucchini', 'Coliflor', 'Tomate'],
      prepTime: 20,
      nutrients: {
        calcio: '25mg',
        hierro: '1.2mg',
        vitaminaA: '1800IU',
        vitaminaC: '32mg'
      }
    },
    {
      id: 'dinner_2',
      name: 'Pescado Blanco al Horno',
      category: 'Cena',
      calories: 380,
      protein: 44,
      carbs: 32,
      fat: 10,
      fiber: 3,
      description: '250g bacalao + papa + verduras',
      ingredients: ['Bacalao', 'Papa cocida', 'Espárragos', 'Cebolla'],
      prepTime: 25,
      nutrients: {
        calcio: '30mg',
        hierro: '0.9mg',
        vitaminaA: '1200IU',
        vitaminaC: '28mg'
      }
    },
    {
      id: 'dinner_3',
      name: 'Huevo Cocido con Verduras',
      category: 'Cena',
      calories: 320,
      protein: 28,
      carbs: 25,
      fat: 11,
      fiber: 5,
      description: '3 huevos cocidos + ensalada',
      ingredients: ['Huevos', 'Lechuga', 'Tomate', 'Pepino', 'Aceite de oliva'],
      prepTime: 10,
      nutrients: {
        calcio: '75mg',
        hierro: '2.8mg',
        vitaminaA: '1500IU',
        vitaminaC: '18mg'
      }
    },
    {
      id: 'dinner_4',
      name: 'Pavo Molido a la Italiana',
      category: 'Cena',
      calories: 400,
      protein: 42,
      carbs: 38,
      fat: 10,
      fiber: 4,
      description: '200g pavo + pasta integral + salsa',
      ingredients: ['Pavo molido', 'Pasta integral', 'Tomate', 'Ajo', 'Cebolla'],
      prepTime: 22,
      nutrients: {
        calcio: '40mg',
        hierro: '2.5mg',
        vitaminaA: '800IU',
        vitaminaC: '15mg'
      }
    },
    {
      id: 'dinner_5',
      name: 'Tofu a la Parrilla',
      category: 'Cena',
      calories: 360,
      protein: 32,
      carbs: 28,
      fat: 14,
      fiber: 4,
      description: 'Tofu firme + vegetales a la parrilla',
      ingredients: ['Tofu', 'Zucchini', 'Champiñones', 'Cebolla roja'],
      prepTime: 18,
      nutrients: {
        calcio: '280mg',
        hierro: '3.2mg',
        vitaminaA: '900IU',
        vitaminaC: '22mg'
      }
    },
    {
      id: 'dinner_6',
      name: 'Sopa de Pollo y Verduras',
      category: 'Cena',
      calories: 340,
      protein: 32,
      carbs: 35,
      fat: 7,
      fiber: 6,
      description: 'Caldo con pollo + vegetales + fideos integrales',
      ingredients: ['Pollo', 'Zanahoria', 'Apio', 'Cebolla', 'Fideos integrales'],
      prepTime: 30,
      nutrients: {
        calcio: '35mg',
        hierro: '2.0mg',
        vitaminaA: '5500IU',
        vitaminaC: '12mg'
      }
    },
    {
      id: 'dinner_7',
      name: 'Filete Magro Ligero',
      category: 'Cena',
      calories: 420,
      protein: 50,
      carbs: 30,
      fat: 12,
      fiber: 3,
      description: '180g carne magra + papas al horno',
      ingredients: ['Carne magra', 'Papas', 'Brócoli', 'Ajo'],
      prepTime: 28,
      nutrients: {
        calcio: '20mg',
        hierro: '3.8mg',
        vitaminaA: '1200IU',
        vitaminaC: '35mg'
      }
    },
    {
      id: 'dinner_8',
      name: 'Camarones al Ajillo',
      category: 'Cena',
      calories: 340,
      protein: 38,
      carbs: 25,
      fat: 9,
      fiber: 3,
      description: '250g camarones + zucchini + papa',
      ingredients: ['Camarones', 'Ajo', 'Zucchini', 'Papa', 'Aceite de oliva'],
      prepTime: 15,
      nutrients: {
        calcio: '60mg',
        hierro: '2.5mg',
        vitaminaA: '700IU',
        vitaminaC: '28mg'
      }
    }
  ],

  meriendas: [
    {
      id: 'snack_1',
      name: 'Manzana con Almendras',
      category: 'Merienda',
      calories: 180,
      protein: 5,
      carbs: 22,
      fat: 9,
      fiber: 4,
      description: '1 manzana + puñado de almendras',
      ingredients: ['Manzana', 'Almendras'],
      prepTime: 0,
      nutrients: {
        calcio: '20mg',
        hierro: '0.6mg',
        vitaminaA: '150IU',
        vitaminaC: '8mg'
      }
    },
    {
      id: 'snack_2',
      name: 'Barrita Proteica',
      category: 'Merienda',
      calories: 200,
      protein: 20,
      carbs: 20,
      fat: 6,
      fiber: 3,
      description: 'Barrita casera o comercial de proteína',
      ingredients: ['Proteína', 'Avena', 'Frutas secas'],
      prepTime: 0,
      nutrients: {
        calcio: '100mg',
        hierro: '1.5mg',
        vitaminaA: '200IU',
        vitaminaC: '2mg'
      }
    },
    {
      id: 'snack_3',
      name: 'Yogur con Miel',
      category: 'Merienda',
      calories: 150,
      protein: 10,
      carbs: 20,
      fat: 3,
      fiber: 1,
      description: 'Yogur natural + miel',
      ingredients: ['Yogur', 'Miel'],
      prepTime: 0,
      nutrients: {
        calcio: '300mg',
        hierro: '0.2mg',
        vitaminaA: '100IU',
        vitaminaC: '1mg'
      }
    },
    {
      id: 'snack_4',
      name: 'Mix de Frutos Secos',
      category: 'Merienda',
      calories: 220,
      protein: 7,
      carbs: 18,
      fat: 15,
      fiber: 3,
      description: 'Almendras, nueces y cacahuetes',
      ingredients: ['Almendras', 'Nueces', 'Cacahuetes'],
      prepTime: 0,
      nutrients: {
        calcio: '80mg',
        hierro: '2.5mg',
        vitaminaA: '0IU',
        vitaminaC: '0mg'
      }
    }
  ]
};

// Función para calcular macros totales
export const calculateTotalMacros = (meals) => {
  let totals = {
    calories: 0,
    protein: 0,
    carbs: 0,
    fat: 0,
    fiber: 0
  };

  meals.forEach(meal => {
    totals.calories += meal.calories;
    totals.protein += meal.protein;
    totals.carbs += meal.carbs;
    totals.fat += meal.fat;
    totals.fiber += meal.fiber;
  });

  return totals;
};

// Función para obtener comidas por categoría
export const getMealsByCategory = (category) => {
  return mealsDatabase[category] || [];
};

// Función para buscar comida por nombre
export const searchMeal = (query) => {
  const lowerQuery = query.toLowerCase();
  let results = [];

  for (const category in mealsDatabase) {
    results = [
      ...results,
      ...mealsDatabase[category].filter(meal =>
        meal.name.toLowerCase().includes(lowerQuery)
      )
    ];
  }

  return results;
};

// Función para obtener todas las comidas
export const getAllMeals = () => {
  let all = [];
  for (const category in mealsDatabase) {
    all = [...all, ...mealsDatabase[category]];
  }
  return all;
};

// Función para obtener recomendaciones calóricas
export const getCalorieRecommendations = (goal) => {
  const recommendations = {
    perderPeso: {
      descripcion: 'Déficit calórico',
      dailyCalories: 1800,
      protein: 140,
      carbs: 135,
      fat: 60
    },
    mantener: {
      descripcion: 'Mantenimiento',
      dailyCalories: 2200,
      protein: 165,
      carbs: 275,
      fat: 73
    },
    ganarMusculo: {
      descripcion: 'Superávit calórico',
      dailyCalories: 2800,
      protein: 210,
      carbs: 350,
      fat: 93
    }
  };

  return recommendations[goal] || recommendations.mantener;
};
