// Database de Ejercicios Expandida
export const exercisesDatabase = {
  // PECHO
  chest: [
    {
      id: 'chest_1',
      name: 'Press de Banca',
      muscle: 'Pecho',
      difficulty: 'Intermedio',
      reps: '8-12',
      sets: 4,
      rest: 90,
      description: 'Acuéstate en banco, baja la barra hasta el pecho, empuja hacia arriba',
      equipment: 'Barra',
      videoUrl: 'chest_press',
      caloriesBurned: 12
    },
    {
      id: 'chest_2',
      name: 'Flexiones',
      muscle: 'Pecho',
      difficulty: 'Principiante',
      reps: '10-20',
      sets: 3,
      rest: 60,
      description: 'Posición de tabla, baja el cuerpo hasta casi tocar el piso',
      equipment: 'Peso corporal',
      videoUrl: 'push_ups',
      caloriesBurned: 8
    },
    {
      id: 'chest_3',
      name: 'Aperturas con Mancuernas',
      muscle: 'Pecho',
      difficulty: 'Intermedio',
      reps: '10-15',
      sets: 3,
      rest: 60,
      description: 'De pie, abre los brazos en arco controlado con mancuernas',
      equipment: 'Mancuernas',
      videoUrl: 'dumbbell_flyes',
      caloriesBurned: 9
    },
    {
      id: 'chest_4',
      name: 'Press Inclinado',
      muscle: 'Pecho Superior',
      difficulty: 'Intermedio',
      reps: '8-12',
      sets: 4,
      rest: 90,
      description: 'Press de banca con banco inclinado 45°',
      equipment: 'Barra',
      videoUrl: 'incline_press',
      caloriesBurned: 11
    },
    {
      id: 'chest_5',
      name: 'Fondos en Barras',
      muscle: 'Pecho',
      difficulty: 'Avanzado',
      reps: '6-12',
      sets: 3,
      rest: 90,
      description: 'Cuelga de barras paralelas y baja el cuerpo',
      equipment: 'Barras Paralelas',
      videoUrl: 'dips',
      caloriesBurned: 10
    }
  ],

  // ESPALDA
  back: [
    {
      id: 'back_1',
      name: 'Dominadas',
      muscle: 'Espalda',
      difficulty: 'Intermedio',
      reps: '6-12',
      sets: 4,
      rest: 90,
      description: 'Cuelga de barra y sube tirando con la espalda',
      equipment: 'Barra',
      videoUrl: 'pull_ups',
      caloriesBurned: 11
    },
    {
      id: 'back_2',
      name: 'Remo con Barra',
      muscle: 'Espalda',
      difficulty: 'Intermedio',
      reps: '8-12',
      sets: 4,
      rest: 90,
      description: 'Inclinate, tira la barra hacia tu abdomen',
      equipment: 'Barra',
      videoUrl: 'barbell_row',
      caloriesBurned: 12
    },
    {
      id: 'back_3',
      name: 'Remo con Mancuernas',
      muscle: 'Espalda',
      difficulty: 'Intermedio',
      reps: '10-12',
      sets: 3,
      rest: 60,
      description: 'Apoya una rodilla, tira mancuerna hacia la cadera',
      equipment: 'Mancuernas',
      videoUrl: 'dumbbell_row',
      caloriesBurned: 10
    },
    {
      id: 'back_4',
      name: 'Jalón Frontal (Lat Pulldown)',
      muscle: 'Espalda Ancha',
      difficulty: 'Principiante',
      reps: '10-15',
      sets: 3,
      rest: 60,
      description: 'Tira la cuerda hacia el pecho desde arriba',
      equipment: 'Máquina',
      videoUrl: 'lat_pulldown',
      caloriesBurned: 9
    },
    {
      id: 'back_5',
      name: 'Peso Muerto',
      muscle: 'Espalda Baja',
      difficulty: 'Avanzado',
      reps: '5-8',
      sets: 4,
      rest: 120,
      description: 'Levanta barra desde el piso hasta caderas',
      equipment: 'Barra',
      videoUrl: 'deadlift',
      caloriesBurned: 15
    },
    {
      id: 'back_6',
      name: 'Remo en Máquina Horizontal',
      muscle: 'Espalda',
      difficulty: 'Principiante',
      reps: '10-15',
      sets: 3,
      rest: 60,
      description: 'Sentado, tira la manija hacia tu abdomen',
      equipment: 'Máquina',
      videoUrl: 'machine_row',
      caloriesBurned: 8
    }
  ],

  // PIERNAS
  legs: [
    {
      id: 'legs_1',
      name: 'Sentadilla',
      muscle: 'Piernas',
      difficulty: 'Intermedio',
      reps: '8-12',
      sets: 4,
      rest: 90,
      description: 'Baja como si fueras a sentarte, mantén el pecho arriba',
      equipment: 'Barra',
      videoUrl: 'squat',
      caloriesBurned: 14
    },
    {
      id: 'legs_2',
      name: 'Estocada (Lunges)',
      muscle: 'Piernas',
      difficulty: 'Intermedio',
      reps: '10-12 cada lado',
      sets: 3,
      rest: 60,
      description: 'Paso adelante, baja cadera hasta que rodilla trasera casi toque piso',
      equipment: 'Mancuernas/Peso corporal',
      videoUrl: 'lunges',
      caloriesBurned: 10
    },
    {
      id: 'legs_3',
      name: 'Prensa de Piernas',
      muscle: 'Piernas',
      difficulty: 'Principiante',
      reps: '10-15',
      sets: 3,
      rest: 75,
      description: 'Sentado, empuja plataforma con pies',
      equipment: 'Máquina',
      videoUrl: 'leg_press',
      caloriesBurned: 11
    },
    {
      id: 'legs_4',
      name: 'Extensión de Cuádriceps',
      muscle: 'Cuádriceps',
      difficulty: 'Principiante',
      reps: '12-15',
      sets: 3,
      rest: 60,
      description: 'Extiende las piernas contra resistencia sentado',
      equipment: 'Máquina',
      videoUrl: 'leg_extension',
      caloriesBurned: 7
    },
    {
      id: 'legs_5',
      name: 'Flexión de Rodilla (Hamstring Curl)',
      muscle: 'Isquiotibiales',
      difficulty: 'Principiante',
      reps: '12-15',
      sets: 3,
      rest: 60,
      description: 'Flexiona las piernas contra resistencia tumbado',
      equipment: 'Máquina',
      videoUrl: 'hamstring_curl',
      caloriesBurned: 7
    },
    {
      id: 'legs_6',
      name: 'Sentadilla Búlgara',
      muscle: 'Piernas',
      difficulty: 'Avanzado',
      reps: '8-12 cada lado',
      sets: 3,
      rest: 75,
      description: 'Pie trasero elevado, baja en sentadilla',
      equipment: 'Mancuernas',
      videoUrl: 'bulgarian_split_squat',
      caloriesBurned: 9
    }
  ],

  // HOMBROS
  shoulders: [
    {
      id: 'shoulders_1',
      name: 'Press de Hombro',
      muscle: 'Hombros',
      difficulty: 'Intermedio',
      reps: '8-12',
      sets: 4,
      rest: 90,
      description: 'De pie o sentado, empuja barra sobre la cabeza',
      equipment: 'Barra',
      videoUrl: 'overhead_press',
      caloriesBurned: 11
    },
    {
      id: 'shoulders_2',
      name: 'Elevaciones Laterales',
      muscle: 'Deltoides Lateral',
      difficulty: 'Principiante',
      reps: '12-15',
      sets: 3,
      rest: 60,
      description: 'Con mancuernas, levanta brazos hacia los lados',
      equipment: 'Mancuernas',
      videoUrl: 'lateral_raises',
      caloriesBurned: 7
    },
    {
      id: 'shoulders_3',
      name: 'Elevaciones Frontales',
      muscle: 'Deltoides Frontal',
      difficulty: 'Principiante',
      reps: '12-15',
      sets: 3,
      rest: 60,
      description: 'Levanta mancuernas hacia el frente hasta altura del hombro',
      equipment: 'Mancuernas',
      videoUrl: 'front_raises',
      caloriesBurned: 6
    },
    {
      id: 'shoulders_4',
      name: 'Pájaros Invertidos',
      muscle: 'Deltoides Posterior',
      difficulty: 'Principiante',
      reps: '12-15',
      sets: 3,
      rest: 60,
      description: 'Inclinate hacia adelante, abre brazos hacia los lados',
      equipment: 'Mancuernas',
      videoUrl: 'reverse_flyes',
      caloriesBurned: 7
    },
    {
      id: 'shoulders_5',
      name: 'Encogimientos de Hombro (Shrugs)',
      muscle: 'Trapecios',
      difficulty: 'Principiante',
      reps: '12-15',
      sets: 3,
      rest: 60,
      description: 'Levanta hombros hacia las orejas contra resistencia',
      equipment: 'Mancuernas/Barra',
      videoUrl: 'shrugs',
      caloriesBurned: 8
    }
  ],

  // BRAZOS
  arms: [
    {
      id: 'arms_1',
      name: 'Curl de Bíceps',
      muscle: 'Bíceps',
      difficulty: 'Principiante',
      reps: '10-12',
      sets: 3,
      rest: 60,
      description: 'Flexiona los codos levantando mancuernas',
      equipment: 'Mancuernas',
      videoUrl: 'bicep_curl',
      caloriesBurned: 6
    },
    {
      id: 'arms_2',
      name: 'Extensión de Tríceps',
      muscle: 'Tríceps',
      difficulty: 'Principiante',
      reps: '10-12',
      sets: 3,
      rest: 60,
      description: 'Extiende brazos hacia atrás contra resistencia',
      equipment: 'Mancuernas/Cuerda',
      videoUrl: 'tricep_extension',
      caloriesBurned: 6
    },
    {
      id: 'arms_3',
      name: 'Curl de Martillo',
      muscle: 'Bíceps',
      difficulty: 'Principiante',
      reps: '10-12',
      sets: 3,
      rest: 60,
      description: 'Curl con mancuernas en posición de martillo',
      equipment: 'Mancuernas',
      videoUrl: 'hammer_curl',
      caloriesBurned: 6
    },
    {
      id: 'arms_4',
      name: 'Fondos de Tríceps',
      muscle: 'Tríceps',
      difficulty: 'Intermedio',
      reps: '8-12',
      sets: 3,
      rest: 75,
      description: 'Baja el cuerpo usando solo los brazos',
      equipment: 'Banco/Barras Paralelas',
      videoUrl: 'tricep_dips',
      caloriesBurned: 9
    },
    {
      id: 'arms_5',
      name: 'Curl en Banca Scott',
      muscle: 'Bíceps',
      difficulty: 'Intermedio',
      reps: '10-12',
      sets: 3,
      rest: 60,
      description: 'Brazos apoyados en banca inclinada, curl controlado',
      equipment: 'Barra',
      videoUrl: 'scott_curl',
      caloriesBurned: 7
    }
  ],

  // CORE/ABDOMINALES
  core: [
    {
      id: 'core_1',
      name: 'Flexiones de Abdominales',
      muscle: 'Abdominales',
      difficulty: 'Principiante',
      reps: '15-20',
      sets: 3,
      rest: 45,
      description: 'Tumbado, levanta el torso hacia las rodillas',
      equipment: 'Peso corporal',
      videoUrl: 'crunches',
      caloriesBurned: 5
    },
    {
      id: 'core_2',
      name: 'Tabla (Plank)',
      muscle: 'Core',
      difficulty: 'Principiante',
      reps: '30-60 seg',
      sets: 3,
      rest: 45,
      description: 'Posición de flexión, mantén el cuerpo recto',
      equipment: 'Peso corporal',
      videoUrl: 'plank',
      caloriesBurned: 6
    },
    {
      id: 'core_3',
      name: 'Levantamiento de Piernas',
      muscle: 'Abdominales Inferiores',
      difficulty: 'Principiante',
      reps: '12-15',
      sets: 3,
      rest: 45,
      description: 'Cuelga de barra, levanta piernas hasta altura de caderas',
      equipment: 'Barra',
      videoUrl: 'leg_raises',
      caloriesBurned: 8
    },
    {
      id: 'core_4',
      name: 'Giro Ruso',
      muscle: 'Oblicuos',
      difficulty: 'Principiante',
      reps: '20 (10 cada lado)',
      sets: 3,
      rest: 45,
      description: 'Sentado, gira el torso de un lado a otro',
      equipment: 'Disco/Peso corporal',
      videoUrl: 'russian_twist',
      caloriesBurned: 7
    },
    {
      id: 'core_5',
      name: 'Mountain Climbers',
      muscle: 'Core',
      difficulty: 'Intermedio',
      reps: '30 seg',
      sets: 3,
      rest: 45,
      description: 'Posición de tabla, lleva rodillas hacia el pecho alternadamente',
      equipment: 'Peso corporal',
      videoUrl: 'mountain_climbers',
      caloriesBurned: 9
    }
  ],

  // CARDIO
  cardio: [
    {
      id: 'cardio_1',
      name: 'Trote',
      muscle: 'Cardio',
      difficulty: 'Principiante',
      duration: '20-30 min',
      sets: 1,
      rest: 0,
      description: 'Corre a ritmo moderado constante',
      equipment: 'Peso corporal',
      videoUrl: 'running',
      caloriesBurned: 10
    },
    {
      id: 'cardio_2',
      name: 'Bicicleta',
      muscle: 'Cardio',
      difficulty: 'Principiante',
      duration: '20-30 min',
      sets: 1,
      rest: 0,
      description: 'Pedalea a ritmo constante',
      equipment: 'Bicicleta',
      videoUrl: 'cycling',
      caloriesBurned: 9
    },
    {
      id: 'cardio_3',
      name: 'Saltar Cuerda',
      muscle: 'Cardio',
      difficulty: 'Intermedio',
      duration: '10-15 min',
      sets: 3,
      rest: 60,
      description: 'Salta continuamente con cuerda',
      equipment: 'Cuerda',
      videoUrl: 'jump_rope',
      caloriesBurned: 13
    },
    {
      id: 'cardio_4',
      name: 'HIIT (Sprint)',
      muscle: 'Cardio',
      difficulty: 'Avanzado',
      duration: '20-30 seg',
      sets: 8,
      rest: 90,
      description: 'Sprints máxima velocidad con recuperación',
      equipment: 'Peso corporal',
      videoUrl: 'sprints',
      caloriesBurned: 15
    }
  ]
};

// Función para obtener ejercicios por músculo
export const getExercisesByMuscle = (muscle) => {
  for (const category in exercisesDatabase) {
    const exercises = exercisesDatabase[category];
    const found = exercises.find(ex => ex.muscle === muscle || ex.muscle.includes(muscle));
    if (found) return exercises;
  }
  return [];
};

// Función para obtener todos los ejercicios
export const getAllExercises = () => {
  let all = [];
  for (const category in exercisesDatabase) {
    all = [...all, ...exercisesDatabase[category]];
  }
  return all;
};
