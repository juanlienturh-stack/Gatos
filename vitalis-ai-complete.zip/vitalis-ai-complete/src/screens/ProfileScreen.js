import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  TextInput,
  Alert
} from 'react-native';

const ProfileScreen = () => {
  const [profile, setProfile] = useState({
    name: 'Usuario',
    email: 'usuario@example.com',
    age: 25,
    weight: 75,
    height: 180,
    goal: 'ganarMusculo'
  });

  const [isEditing, setIsEditing] = useState(false);
  const [tempProfile, setTempProfile] = useState(profile);

  const calculateBMI = () => {
    const heightInMeters = profile.height / 100;
    const bmi = profile.weight / (heightInMeters * heightInMeters);
    return bmi.toFixed(1);
  };

  const getBMICategory = () => {
    const bmi = parseFloat(calculateBMI());
    if (bmi < 18.5) return { category: 'Bajo peso', color: '#2196F3' };
    if (bmi < 25) return { category: 'Normal', color: '#4CAF50' };
    if (bmi < 30) return { category: 'Sobrepeso', color: '#FF9800' };
    return { category: 'Obeso', color: '#F44336' };
  };

  const getCalorieGoal = () => {
    const goals = {
      perderPeso: 1800,
      mantener: 2200,
      ganarMusculo: 2800
    };
    return goals[profile.goal] || 2200;
  };

  const handleSave = () => {
    setProfile(tempProfile);
    setIsEditing(false);
    Alert.alert('Éxito', 'Tu perfil ha sido actualizado');
  };

  const handleCancel = () => {
    setTempProfile(profile);
    setIsEditing(false);
  };

  const bmiInfo = getBMICategory();

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Mi Perfil</Text>
        </View>

        {/* Foto de Perfil */}
        <View style={styles.profilePictureContainer}>
          <View style={styles.profilePicture}>
            <Text style={styles.profilePictureText}>👤</Text>
          </View>
          <Text style={styles.profileName}>{tempProfile.name}</Text>
          <Text style={styles.profileEmail}>{tempProfile.email}</Text>
        </View>

        {/* Información Personal */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>📋 Información Personal</Text>
            {!isEditing && (
              <TouchableOpacity onPress={() => setIsEditing(true)}>
                <Text style={styles.editButton}>✏️ Editar</Text>
              </TouchableOpacity>
            )}
          </View>

          <View style={styles.infoCard}>
            {isEditing ? (
              <>
                <View style={styles.inputGroup}>
                  <Text style={styles.label}>Nombre</Text>
                  <TextInput
                    style={styles.input}
                    value={tempProfile.name}
                    onChangeText={(text) =>
                      setTempProfile({ ...tempProfile, name: text })
                    }
                    placeholder="Tu nombre"
                  />
                </View>

                <View style={styles.inputGroup}>
                  <Text style={styles.label}>Edad</Text>
                  <TextInput
                    style={styles.input}
                    value={String(tempProfile.age)}
                    onChangeText={(text) =>
                      setTempProfile({ ...tempProfile, age: parseInt(text) || 0 })
                    }
                    placeholder="Tu edad"
                    keyboardType="numeric"
                  />
                </View>

                <View style={styles.inputGroup}>
                  <Text style={styles.label}>Peso (kg)</Text>
                  <TextInput
                    style={styles.input}
                    value={String(tempProfile.weight)}
                    onChangeText={(text) =>
                      setTempProfile({ ...tempProfile, weight: parseFloat(text) || 0 })
                    }
                    placeholder="Tu peso"
                    keyboardType="decimal-pad"
                  />
                </View>

                <View style={styles.inputGroup}>
                  <Text style={styles.label}>Altura (cm)</Text>
                  <TextInput
                    style={styles.input}
                    value={String(tempProfile.height)}
                    onChangeText={(text) =>
                      setTempProfile({ ...tempProfile, height: parseInt(text) || 0 })
                    }
                    placeholder="Tu altura"
                    keyboardType="numeric"
                  />
                </View>

                <View style={styles.buttonGroup}>
                  <TouchableOpacity
                    style={styles.saveButton}
                    onPress={handleSave}
                  >
                    <Text style={styles.saveButtonText}>✓ Guardar</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={styles.cancelButton}
                    onPress={handleCancel}
                  >
                    <Text style={styles.cancelButtonText}>✕ Cancelar</Text>
                  </TouchableOpacity>
                </View>
              </>
            ) : (
              <>
                <View style={styles.infoRow}>
                  <Text style={styles.infoLabel}>Edad:</Text>
                  <Text style={styles.infoValue}>{profile.age} años</Text>
                </View>
                <View style={styles.infoRow}>
                  <Text style={styles.infoLabel}>Peso:</Text>
                  <Text style={styles.infoValue}>{profile.weight} kg</Text>
                </View>
                <View style={styles.infoRow}>
                  <Text style={styles.infoLabel}>Altura:</Text>
                  <Text style={styles.infoValue}>{profile.height} cm</Text>
                </View>
              </>
            )}
          </View>
        </View>

        {/* IMC */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>📊 Índice de Masa Corporal</Text>

          <View style={[styles.bmiCard, { borderLeftColor: bmiInfo.color }]}>
            <View style={styles.bmiContent}>
              <Text style={styles.bmiValue}>{calculateBMI()}</Text>
              <Text style={[styles.bmiCategory, { color: bmiInfo.color }]}>
                {bmiInfo.category}
              </Text>
            </View>
            <View style={[styles.bmiBadge, { backgroundColor: bmiInfo.color }]}>
              <Text style={styles.bmiBadgeText}>IMC</Text>
            </View>
          </View>

          <View style={styles.bmiInfo}>
            <Text style={styles.bmiInfoText}>
              El IMC es una medida de la relación entre tu peso y altura. Un IMC normal está entre 18.5 y 24.9.
            </Text>
          </View>
        </View>

        {/* Objetivo de Fitness */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>🎯 Objetivo de Fitness</Text>

          <View style={styles.goalContainer}>
            <TouchableOpacity
              style={[
                styles.goalOption,
                profile.goal === 'perderPeso' && styles.goalOptionActive
              ]}
              onPress={() => setTempProfile({ ...tempProfile, goal: 'perderPeso' })}
            >
              <Text style={styles.goalEmoji}>⬇️</Text>
              <Text style={styles.goalText}>Perder Peso</Text>
              <Text style={styles.goalCalories}>1800 cal/día</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[
                styles.goalOption,
                profile.goal === 'mantener' && styles.goalOptionActive
              ]}
              onPress={() => setTempProfile({ ...tempProfile, goal: 'mantener' })}
            >
              <Text style={styles.goalEmoji}>➡️</Text>
              <Text style={styles.goalText}>Mantener</Text>
              <Text style={styles.goalCalories}>2200 cal/día</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[
                styles.goalOption,
                profile.goal === 'ganarMusculo' && styles.goalOptionActive
              ]}
              onPress={() => setTempProfile({ ...tempProfile, goal: 'ganarMusculo' })}
            >
              <Text style={styles.goalEmoji}>⬆️</Text>
              <Text style={styles.goalText}>Ganar Músculo</Text>
              <Text style={styles.goalCalories}>2800 cal/día</Text>
            </TouchableOpacity>
          </View>

          {isEditing && (
            <View style={styles.buttonGroup}>
              <TouchableOpacity
                style={styles.saveButton}
                onPress={handleSave}
              >
                <Text style={styles.saveButtonText}>✓ Guardar Cambios</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>

        {/* Recomendaciones */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>💡 Recomendaciones</Text>

          <View style={styles.recommendationCard}>
            <Text style={styles.recommendationTitle}>Calorías Diarias Recomendadas</Text>
            <Text style={styles.recommendationValue}>{getCalorieGoal()} kcal</Text>
            <Text style={styles.recommendationText}>
              Basado en tu objetivo y datos personales
            </Text>
          </View>

          <View style={styles.recommendationCard}>
            <Text style={styles.recommendationTitle}>Ingesta de Proteína</Text>
            <Text style={styles.recommendationValue}>
              {Math.round(profile.weight * 1.6)} - {Math.round(profile.weight * 2.2)}g
            </Text>
            <Text style={styles.recommendationText}>
              Aproximadamente 1.6 - 2.2g por kg de peso corporal
            </Text>
          </View>

          <View style={styles.recommendationCard}>
            <Text style={styles.recommendationTitle}>Agua Diaria</Text>
            <Text style={styles.recommendationValue}>
              {Math.round(profile.weight * 30)}ml
            </Text>
            <Text style={styles.recommendationText}>
              Aproximadamente 30ml por kg de peso corporal
            </Text>
          </View>
        </View>

        {/* Botones de Acción */}
        <View style={styles.section}>
          <TouchableOpacity style={styles.dangerButton}>
            <Text style={styles.dangerButtonText}>🔓 Cerrar Sesión</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.secondaryButton}>
            <Text style={styles.secondaryButtonText}>📧 Contáctanos</Text>
          </TouchableOpacity>
        </View>

        <View style={{ height: 40 }} />
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F7FA'
  },

  header: {
    paddingHorizontal: 16,
    paddingTop: 20,
    paddingBottom: 16
  },

  title: {
    fontSize: 28,
    fontWeight: '700',
    color: '#1A1A1A'
  },

  profilePictureContainer: {
    alignItems: 'center',
    marginBottom: 24,
    paddingVertical: 16
  },

  profilePicture: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#2196F3',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12
  },

  profilePictureText: {
    fontSize: 48
  },

  profileName: {
    fontSize: 20,
    fontWeight: '700',
    color: '#1A1A1A',
    marginBottom: 4
  },

  profileEmail: {
    fontSize: 13,
    color: '#666',
    fontWeight: '500'
  },

  section: {
    paddingHorizontal: 16,
    marginBottom: 24
  },

  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12
  },

  sectionTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#1A1A1A'
  },

  editButton: {
    fontSize: 13,
    color: '#2196F3',
    fontWeight: '600'
  },

  infoCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2
  },

  inputGroup: {
    marginBottom: 16
  },

  label: {
    fontSize: 12,
    color: '#666',
    fontWeight: '600',
    marginBottom: 6
  },

  input: {
    backgroundColor: '#F5F7FA',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 14,
    color: '#1A1A1A',
    borderWidth: 1,
    borderColor: '#E0E0E0'
  },

  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0'
  },

  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0'
  },

  infoLabel: {
    fontSize: 13,
    color: '#666',
    fontWeight: '600'
  },

  infoValue: {
    fontSize: 13,
    color: '#1A1A1A',
    fontWeight: '700'
  },

  bmiCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderLeftWidth: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2
  },

  bmiContent: {
    flex: 1
  },

  bmiValue: {
    fontSize: 28,
    fontWeight: '700',
    color: '#1A1A1A'
  },

  bmiCategory: {
    fontSize: 13,
    fontWeight: '600',
    marginTop: 4
  },

  bmiBadge: {
    width: 60,
    height: 60,
    borderRadius: 30,
    alignItems: 'center',
    justifyContent: 'center'
  },

  bmiBadgeText: {
    fontSize: 11,
    color: '#FFFFFF',
    fontWeight: '700'
  },

  bmiInfo: {
    backgroundColor: '#E3F2FD',
    borderRadius: 8,
    padding: 12
  },

  bmiInfoText: {
    fontSize: 12,
    color: '#1565C0',
    lineHeight: 18,
    fontWeight: '500'
  },

  goalContainer: {
    gap: 10
  },

  goalOption: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#E0E0E0',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2
  },

  goalOptionActive: {
    borderColor: '#2196F3',
    backgroundColor: '#E3F2FD'
  },

  goalEmoji: {
    fontSize: 20,
    marginRight: 12
  },

  goalText: {
    flex: 1,
    fontSize: 14,
    fontWeight: '600',
    color: '#1A1A1A'
  },

  goalCalories: {
    fontSize: 11,
    color: '#666',
    fontWeight: '500'
  },

  recommendationCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 14,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2
  },

  recommendationTitle: {
    fontSize: 12,
    color: '#666',
    fontWeight: '600',
    marginBottom: 4
  },

  recommendationValue: {
    fontSize: 18,
    fontWeight: '700',
    color: '#2196F3',
    marginBottom: 4
  },

  recommendationText: {
    fontSize: 11,
    color: '#999',
    fontWeight: '500'
  },

  buttonGroup: {
    flexDirection: 'row',
    gap: 10,
    marginTop: 12
  },

  saveButton: {
    flex: 1,
    backgroundColor: '#4CAF50',
    borderRadius: 10,
    paddingVertical: 12,
    alignItems: 'center'
  },

  saveButtonText: {
    fontSize: 14,
    fontWeight: '700',
    color: '#FFFFFF'
  },

  cancelButton: {
    flex: 1,
    backgroundColor: '#FFE0E0',
    borderRadius: 10,
    paddingVertical: 12,
    alignItems: 'center'
  },

  cancelButtonText: {
    fontSize: 14,
    fontWeight: '700',
    color: '#FF6B6B'
  },

  dangerButton: {
    backgroundColor: '#FF6B6B',
    borderRadius: 10,
    paddingVertical: 14,
    alignItems: 'center',
    marginBottom: 10
  },

  dangerButtonText: {
    fontSize: 15,
    fontWeight: '700',
    color: '#FFFFFF'
  },

  secondaryButton: {
    backgroundColor: '#E0E0E0',
    borderRadius: 10,
    paddingVertical: 14,
    alignItems: 'center'
  },

  secondaryButtonText: {
    fontSize: 15,
    fontWeight: '700',
    color: '#1A1A1A'
  }
});

export default ProfileScreen;
