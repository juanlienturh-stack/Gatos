import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  Modal,
  FlatList,
  Animated,
  ProgressViewIOS,
  Image
} from 'react-native';
import { exercisesDatabase, getAllExercises } from './database_exercises';

const { width } = Dimensions.get('window');

const WorkoutScreen = () => {
  const [selectedMuscle, setSelectedMuscle] = useState('chest');
  const [selectedExercise, setSelectedExercise] = useState(null);
  const [exerciseModal, setExerciseModal] = useState(false);
  const [workoutPlan, setWorkoutPlan] = useState([]);
  const [repsCompleted, setRepsCompleted] = useState({});

  const muscleGroups = [
    { id: 'chest', name: 'Pecho', emoji: '🏋️', color: '#FF6B6B' },
    { id: 'back', name: 'Espalda', emoji: '🔙', color: '#4ECDC4' },
    { id: 'legs', name: 'Piernas', emoji: '🦵', color: '#95E1D3' },
    { id: 'shoulders', name: 'Hombros', emoji: '💪', color: '#FFE66D' },
    { id: 'arms', name: 'Brazos', emoji: '💯', color: '#A8E6CF' },
    { id: 'core', name: 'Core', emoji: '⭐', color: '#FF8B94' },
    { id: 'cardio', name: 'Cardio', emoji: '🏃', color: '#6BCB77' }
  ];

  const getExercisesForMuscle = () => {
    return exercisesDatabase[selectedMuscle] || [];
  };

  const addExerciseToWorkout = (exercise) => {
    setWorkoutPlan([...workoutPlan, { ...exercise, workoutId: Date.now() }]);
    setExerciseModal(false);
    setSelectedExercise(null);
  };

  const removeExerciseFromWorkout = (workoutId) => {
    setWorkoutPlan(workoutPlan.filter(ex => ex.workoutId !== workoutId));
  };

  const updateRepsCompleted = (workoutId, reps) => {
    setRepsCompleted({
      ...repsCompleted,
      [workoutId]: reps
    });
  };

  // Componente de Botón de Músculo
  const MuscleButton = ({ muscle }) => {
    const isSelected = selectedMuscle === muscle.id;
    return (
      <TouchableOpacity
        style={[
          styles.muscleButton,
          isSelected && { backgroundColor: muscle.color }
        ]}
        onPress={() => setSelectedMuscle(muscle.id)}
      >
        <Text style={styles.muscleEmoji}>{muscle.emoji}</Text>
        <Text
          style={[
            styles.muscleName,
            isSelected && { color: '#FFF' }
          ]}
        >
          {muscle.name}
        </Text>
      </TouchableOpacity>
    );
  };

  // Componente de Ejercicio para Agregar
  const ExerciseOption = ({ exercise }) => (
    <TouchableOpacity
      style={styles.exerciseOption}
      onPress={() => {
        setSelectedExercise(exercise);
        setExerciseModal(false);
      }}
    >
      <View style={styles.exerciseOptionContent}>
        <View>
          <Text style={styles.exerciseName}>{exercise.name}</Text>
          <Text style={styles.exerciseInfo}>
            {exercise.difficulty} • {exercise.reps} reps • {exercise.sets} sets
          </Text>
        </View>
        <View style={styles.caloriesBadge}>
          <Text style={styles.caloriesText}>{exercise.caloriesBurned} cal</Text>
        </View>
      </View>
    </TouchableOpacity>
  );

  // Componente de Ejercicio en el Plan
  const PlanExerciseCard = ({ exercise, workoutId }) => {
    const completed = repsCompleted[workoutId] || 0;
    const completionPercent = (completed / exercise.sets) * 100;

    return (
      <View style={styles.planExerciseCard}>
        {/* Encabezado */}
        <View style={styles.planExerciseHeader}>
          <View style={{ flex: 1 }}>
            <Text style={styles.planExerciseName}>{exercise.name}</Text>
            <Text style={styles.planExerciseSubtitle}>
              {exercise.difficulty} • {exercise.equipment}
            </Text>
          </View>
          <TouchableOpacity
            onPress={() => removeExerciseFromWorkout(workoutId)}
            style={styles.deleteBtn}
          >
            <Text style={styles.deleteBtnText}>🗑️</Text>
          </TouchableOpacity>
        </View>

        {/* Descripción */}
        <Text style={styles.exerciseDescription}>{exercise.description}</Text>

        {/* Series y Reps */}
        <View style={styles.seriesContainer}>
          <View style={styles.seriesBox}>
            <Text style={styles.seriesLabel}>Series</Text>
            <Text style={styles.seriesValue}>{exercise.sets}</Text>
          </View>
          <View style={styles.seriesBox}>
            <Text style={styles.seriesLabel}>Reps/Duración</Text>
            <Text style={styles.seriesValue}>{exercise.reps}</Text>
          </View>
          <View style={styles.seriesBox}>
            <Text style={styles.seriesLabel}>Descanso</Text>
            <Text style={styles.seriesValue}>{exercise.rest}s</Text>
          </View>
          <View style={styles.seriesBox}>
            <Text style={styles.seriesLabel}>Calorías</Text>
            <Text style={styles.seriesValue}>{exercise.caloriesBurned}</Text>
          </View>
        </View>

        {/* Progreso */}
        <View style={styles.progressSection}>
          <View style={styles.progressHeader}>
            <Text style={styles.progressLabel}>Completado: {completed}/{exercise.sets} series</Text>
            <Text style={styles.progressPercent}>{Math.round(completionPercent)}%</Text>
          </View>
          <View style={styles.progressBar}>
            <View
              style={[
                styles.progressFill,
                { width: `${completionPercent}%` }
              ]}
            />
          </View>
        </View>

        {/* Botones de Progreso */}
        <View style={styles.progressButtons}>
          <TouchableOpacity
            style={styles.minusBtn}
            onPress={() => updateRepsCompleted(workoutId, Math.max(0, completed - 1))}
          >
            <Text style={styles.btnText}>−</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.addBtn}
            onPress={() => updateRepsCompleted(workoutId, Math.min(exercise.sets, completed + 1))}
          >
            <Text style={styles.btnText}>+</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[
              styles.completeBtn,
              completed === exercise.sets && styles.completeBtnActive
            ]}
          >
            <Text style={styles.completeBtnText}>
              {completed === exercise.sets ? '✓ Completo' : 'Completar Todo'}
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  // Resumen del Entrenamiento
  const getWorkoutSummary = () => {
    let totalSets = 0;
    let totalCalories = 0;
    let totalDuration = 0;

    workoutPlan.forEach(exercise => {
      totalSets += exercise.sets;
      totalCalories += exercise.caloriesBurned * exercise.sets;
      totalDuration += exercise.rest * exercise.sets;
    });

    return { totalSets, totalCalories, totalDuration };
  };

  const summary = getWorkoutSummary();

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {/* Encabezado */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Mi Entrenamiento</Text>
        <Text style={styles.headerSubtitle}>Selecciona ejercicios y sigue tu progreso</Text>
      </View>

      {/* Selector de Músculos */}
      <View style={styles.muscleSelector}>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.muscleScrollContent}
        >
          {muscleGroups.map(muscle => (
            <MuscleButton key={muscle.id} muscle={muscle} />
          ))}
        </ScrollView>
      </View>

      {/* Tarjeta de Resumen */}
      {workoutPlan.length > 0 && (
        <View style={styles.summaryCard}>
          <Text style={styles.summaryTitle}>Resumen del Entrenamiento</Text>
          <View style={styles.summaryRow}>
            <View style={styles.summaryItem}>
              <Text style={styles.summaryValue}>{workoutPlan.length}</Text>
              <Text style={styles.summaryLabel}>Ejercicios</Text>
            </View>
            <View style={styles.summaryDivider} />
            <View style={styles.summaryItem}>
              <Text style={styles.summaryValue}>{summary.totalSets}</Text>
              <Text style={styles.summaryLabel}>Series</Text>
            </View>
            <View style={styles.summaryDivider} />
            <View style={styles.summaryItem}>
              <Text style={styles.summaryValue}>{summary.totalCalories}</Text>
              <Text style={styles.summaryLabel}>Calorías</Text>
            </View>
          </View>
        </View>
      )}

      {/* Botón para Agregar Ejercicio */}
      <TouchableOpacity
        style={styles.addExerciseBtn}
        onPress={() => setExerciseModal(true)}
      >
        <Text style={styles.addExerciseText}>+ Agregar Ejercicio ({getExercisesForMuscle().length})</Text>
      </TouchableOpacity>

      {/* Plan de Entrenamiento */}
      {workoutPlan.length > 0 ? (
        <View style={styles.planContainer}>
          <Text style={styles.planTitle}>Tu Plan Actual</Text>
          {workoutPlan.map((exercise) => (
            <PlanExerciseCard
              key={exercise.workoutId}
              exercise={exercise}
              workoutId={exercise.workoutId}
            />
          ))}

          {/* Botón de Guardar */}
          <TouchableOpacity style={styles.saveWorkoutBtn}>
            <Text style={styles.saveWorkoutText}>💾 Guardar Entrenamiento</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <View style={styles.emptyState}>
          <Text style={styles.emptyStateEmoji}>🏋️</Text>
          <Text style={styles.emptyStateText}>No hay ejercicios agregados</Text>
          <Text style={styles.emptyStateSubtext}>Selecciona un grupo muscular y agrega ejercicios</Text>
        </View>
      )}

      {/* Modal de Ejercicios */}
      <Modal
        visible={exerciseModal}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setExerciseModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContainer}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>
                Ejercicios para {muscleGroups.find(m => m.id === selectedMuscle)?.name}
              </Text>
              <TouchableOpacity
                onPress={() => setExerciseModal(false)}
                style={styles.modalCloseBtn}
              >
                <Text style={styles.modalCloseBtnText}>✕</Text>
              </TouchableOpacity>
            </View>

            <FlatList
              data={getExercisesForMuscle()}
              keyExtractor={(item) => item.id}
              renderItem={({ item }) => <ExerciseOption exercise={item} />}
              contentContainerStyle={styles.exerciseListContainer}
            />
          </View>
        </View>
      </Modal>

      {/* Vista de Ejercicio Seleccionado */}
      {selectedExercise && (
        <Modal
          visible={!!selectedExercise}
          animationType="slide"
          transparent={true}
          onRequestClose={() => setSelectedExercise(null)}
        >
          <View style={styles.detailModalOverlay}>
            <View style={styles.detailModalContainer}>
              {/* Header */}
              <View style={styles.detailModalHeader}>
                <TouchableOpacity
                  onPress={() => setSelectedExercise(null)}
                  style={styles.backBtn}
                >
                  <Text style={styles.backBtnText}>← Atrás</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => addExerciseToWorkout(selectedExercise)}
                  style={styles.addBtn2}
                >
                  <Text style={styles.addBtn2Text}>+ Agregar</Text>
                </TouchableOpacity>
              </View>

              <ScrollView showsVerticalScrollIndicator={false}>
                {/* Nombre y Dificultad */}
                <View style={styles.detailContent}>
                  <Text style={styles.detailTitle}>{selectedExercise.name}</Text>
                  <View style={styles.difficultyBadge}>
                    <Text style={styles.difficultyText}>{selectedExercise.difficulty}</Text>
                  </View>

                  {/* Descripción */}
                  <View style={styles.detailSection}>
                    <Text style={styles.detailSectionTitle}>Descripción</Text>
                    <Text style={styles.detailDescription}>{selectedExercise.description}</Text>
                  </View>

                  {/* Especificaciones */}
                  <View style={styles.detailSection}>
                    <Text style={styles.detailSectionTitle}>Especificaciones</Text>
                    <View style={styles.specGrid}>
                      <View style={styles.specItem}>
                        <Text style={styles.specLabel}>Series</Text>
                        <Text style={styles.specValue}>{selectedExercise.sets}</Text>
                      </View>
                      <View style={styles.specItem}>
                        <Text style={styles.specLabel}>Reps</Text>
                        <Text style={styles.specValue}>{selectedExercise.reps}</Text>
                      </View>
                      <View style={styles.specItem}>
                        <Text style={styles.specLabel}>Descanso</Text>
                        <Text style={styles.specValue}>{selectedExercise.rest}s</Text>
                      </View>
                      <View style={styles.specItem}>
                        <Text style={styles.specLabel}>Calorías</Text>
                        <Text style={styles.specValue}>{selectedExercise.caloriesBurned}</Text>
                      </View>
                    </View>
                  </View>

                  {/* Equipo */}
                  <View style={styles.detailSection}>
                    <Text style={styles.detailSectionTitle}>Equipo Necesario</Text>
                    <Text style={styles.equipmentText}>{selectedExercise.equipment}</Text>
                  </View>

                  {/* Botón de Agregar al Final */}
                  <TouchableOpacity
                    style={styles.addExerciseLargeBtn}
                    onPress={() => addExerciseToWorkout(selectedExercise)}
                  >
                    <Text style={styles.addExerciseLargeBtnText}>+ Agregar a Mi Plan</Text>
                  </TouchableOpacity>
                </View>
              </ScrollView>
            </View>
          </View>
        </Modal>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F7FA'
  },

  header: {
    paddingHorizontal: 16,
    paddingTop: 20,
    paddingBottom: 16
  },

  headerTitle: {
    fontSize: 28,
    fontWeight: '700',
    color: '#1A1A1A',
    marginBottom: 4
  },

  headerSubtitle: {
    fontSize: 14,
    color: '#666',
    fontWeight: '500'
  },

  // Selector de Músculos
  muscleSelector: {
    marginBottom: 16
  },

  muscleScrollContent: {
    paddingHorizontal: 12,
    gap: 8
  },

  muscleButton: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    paddingVertical: 12,
    paddingHorizontal: 14,
    alignItems: 'center',
    gap: 4,
    minWidth: 80,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2
  },

  muscleEmoji: {
    fontSize: 24
  },

  muscleName: {
    fontSize: 11,
    fontWeight: '600',
    color: '#666'
  },

  // Tarjeta de Resumen
  summaryCard: {
    marginHorizontal: 16,
    marginBottom: 16,
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3
  },

  summaryTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#1A1A1A',
    marginBottom: 12
  },

  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center'
  },

  summaryItem: {
    alignItems: 'center'
  },

  summaryValue: {
    fontSize: 18,
    fontWeight: '700',
    color: '#2196F3'
  },

  summaryLabel: {
    fontSize: 11,
    color: '#666',
    fontWeight: '500',
    marginTop: 4
  },

  summaryDivider: {
    width: 1,
    height: 30,
    backgroundColor: '#E0E0E0'
  },

  // Botón Agregar Ejercicio
  addExerciseBtn: {
    marginHorizontal: 16,
    marginBottom: 16,
    backgroundColor: '#2196F3',
    borderRadius: 10,
    paddingVertical: 14,
    alignItems: 'center'
  },

  addExerciseText: {
    fontSize: 15,
    fontWeight: '600',
    color: '#FFFFFF'
  },

  // Plan Container
  planContainer: {
    paddingHorizontal: 16,
    paddingBottom: 20
  },

  planTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#1A1A1A',
    marginBottom: 12
  },

  // Tarjeta de Ejercicio en Plan
  planExerciseCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2
  },

  planExerciseHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 8
  },

  planExerciseName: {
    fontSize: 16,
    fontWeight: '700',
    color: '#1A1A1A'
  },

  planExerciseSubtitle: {
    fontSize: 12,
    color: '#666',
    marginTop: 2
  },

  deleteBtn: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#FFE0E0',
    alignItems: 'center',
    justifyContent: 'center'
  },

  deleteBtnText: {
    fontSize: 16
  },

  exerciseDescription: {
    fontSize: 13,
    color: '#666',
    marginBottom: 12,
    fontStyle: 'italic'
  },

  seriesContainer: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 12
  },

  seriesBox: {
    flex: 1,
    backgroundColor: '#F5F7FA',
    borderRadius: 8,
    padding: 10,
    alignItems: 'center'
  },

  seriesLabel: {
    fontSize: 10,
    color: '#666',
    fontWeight: '500'
  },

  seriesValue: {
    fontSize: 14,
    fontWeight: '700',
    color: '#1A1A1A',
    marginTop: 4
  },

  progressSection: {
    marginBottom: 12
  },

  progressHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 6
  },

  progressLabel: {
    fontSize: 12,
    fontWeight: '600',
    color: '#666'
  },

  progressPercent: {
    fontSize: 12,
    fontWeight: '700',
    color: '#4CAF50'
  },

  progressBar: {
    height: 8,
    backgroundColor: '#E0E0E0',
    borderRadius: 4,
    overflow: 'hidden'
  },

  progressFill: {
    height: '100%',
    backgroundColor: '#4CAF50',
    borderRadius: 4
  },

  progressButtons: {
    flexDirection: 'row',
    gap: 8
  },

  minusBtn: {
    flex: 1,
    backgroundColor: '#FFE0E0',
    borderRadius: 8,
    paddingVertical: 10,
    alignItems: 'center'
  },

  addBtn: {
    flex: 1,
    backgroundColor: '#E0FFE0',
    borderRadius: 8,
    paddingVertical: 10,
    alignItems: 'center'
  },

  btnText: {
    fontSize: 16,
    fontWeight: '700',
    color: '#1A1A1A'
  },

  completeBtn: {
    flex: 1.2,
    backgroundColor: '#E3F2FD',
    borderRadius: 8,
    paddingVertical: 10,
    alignItems: 'center'
  },

  completeBtnActive: {
    backgroundColor: '#4CAF50'
  },

  completeBtnText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#2196F3'
  },

  saveWorkoutBtn: {
    backgroundColor: '#4CAF50',
    borderRadius: 10,
    paddingVertical: 14,
    alignItems: 'center',
    marginTop: 8,
    shadowColor: '#4CAF50',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 5
  },

  saveWorkoutText: {
    fontSize: 15,
    fontWeight: '700',
    color: '#FFFFFF'
  },

  emptyState: {
    paddingHorizontal: 16,
    paddingVertical: 60,
    alignItems: 'center'
  },

  emptyStateEmoji: {
    fontSize: 48,
    marginBottom: 16
  },

  emptyStateText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1A1A1A',
    marginBottom: 4
  },

  emptyStateSubtext: {
    fontSize: 13,
    color: '#666'
  },

  // Modal styles
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)'
  },

  modalContainer: {
    flex: 1,
    marginTop: 50,
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20
  },

  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0'
  },

  modalTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#1A1A1A',
    flex: 1
  },

  modalCloseBtn: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#F0F0F0',
    alignItems: 'center',
    justifyContent: 'center'
  },

  modalCloseBtnText: {
    fontSize: 18,
    color: '#1A1A1A',
    fontWeight: '700'
  },

  exerciseListContainer: {
    paddingHorizontal: 16,
    paddingVertical: 12
  },

  exerciseOption: {
    backgroundColor: '#F5F7FA',
    borderRadius: 10,
    padding: 12,
    marginBottom: 10,
    borderLeftWidth: 4,
    borderLeftColor: '#2196F3'
  },

  exerciseOptionContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center'
  },

  exerciseName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#1A1A1A'
  },

  exerciseInfo: {
    fontSize: 12,
    color: '#666',
    marginTop: 4
  },

  caloriesBadge: {
    backgroundColor: '#FF6B6B',
    borderRadius: 6,
    paddingHorizontal: 8,
    paddingVertical: 4
  },

  caloriesText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#FFFFFF'
  },

  // Detail Modal
  detailModalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)'
  },

  detailModalContainer: {
    flex: 1,
    marginTop: 40,
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20
  },

  detailModalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0'
  },

  backBtn: {
    paddingVertical: 8,
    paddingHorizontal: 4
  },

  backBtnText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#2196F3'
  },

  addBtn2: {
    backgroundColor: '#4CAF50',
    borderRadius: 8,
    paddingHorizontal: 16,
    paddingVertical: 8
  },

  addBtn2Text: {
    fontSize: 14,
    fontWeight: '600',
    color: '#FFFFFF'
  },

  detailContent: {
    paddingHorizontal: 16,
    paddingVertical: 20
  },

  detailTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: '#1A1A1A',
    marginBottom: 12
  },

  difficultyBadge: {
    alignSelf: 'flex-start',
    backgroundColor: '#FFF3CD',
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 6,
    marginBottom: 16
  },

  difficultyText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#F57F17'
  },

  detailSection: {
    marginBottom: 20
  },

  detailSectionTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#1A1A1A',
    marginBottom: 8
  },

  detailDescription: {
    fontSize: 14,
    color: '#666',
    lineHeight: 20
  },

  specGrid: {
    flexDirection: 'row',
    gap: 8
  },

  specItem: {
    flex: 1,
    backgroundColor: '#F5F7FA',
    borderRadius: 8,
    padding: 10,
    alignItems: 'center'
  },

  specLabel: {
    fontSize: 10,
    color: '#666',
    fontWeight: '500'
  },

  specValue: {
    fontSize: 16,
    fontWeight: '700',
    color: '#2196F3',
    marginTop: 4
  },

  equipmentText: {
    fontSize: 14,
    color: '#666',
    fontWeight: '500',
    backgroundColor: '#F0F8FF',
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 8
  },

  addExerciseLargeBtn: {
    backgroundColor: '#4CAF50',
    borderRadius: 10,
    paddingVertical: 14,
    alignItems: 'center',
    marginTop: 20
  },

  addExerciseLargeBtnText: {
    fontSize: 15,
    fontWeight: '700',
    color: '#FFFFFF'
  }
});

export default WorkoutScreen;
