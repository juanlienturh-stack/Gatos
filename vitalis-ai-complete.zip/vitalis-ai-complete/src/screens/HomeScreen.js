import React from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  SafeAreaView
} from 'react-native';

const { width } = Dimensions.get('window');

const HomeScreen = ({ navigation }) => {
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.greeting}>¡Hola, Usuario! 👋</Text>
          <Text style={styles.date}>11 de Marzo, 2026</Text>
        </View>

        {/* Tarjeta de Resumen Hoy */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>📊 Hoy</Text>
          <View style={styles.statsRow}>
            <View style={styles.stat}>
              <Text style={styles.statValue}>0</Text>
              <Text style={styles.statLabel}>Entrenamientos</Text>
            </View>
            <View style={styles.divider} />
            <View style={styles.stat}>
              <Text style={styles.statValue}>0</Text>
              <Text style={styles.statLabel}>Comidas</Text>
            </View>
            <View style={styles.divider} />
            <View style={styles.stat}>
              <Text style={styles.statValue}>0</Text>
              <Text style={styles.statLabel}>Calorías</Text>
            </View>
          </View>
        </View>

        {/* Motivación */}
        <View style={styles.motivationCard}>
          <Text style={styles.motivationEmoji}>💪</Text>
          <Text style={styles.motivationText}>
            "Tu cuerpo es tu templo. Cuídalo como si fuera un palacio." - Anónimo
          </Text>
        </View>

        {/* Quick Actions */}
        <Text style={styles.sectionTitle}>Acciones Rápidas</Text>

        <View style={styles.quickActionsContainer}>
          <TouchableOpacity
            style={styles.quickAction}
            onPress={() => navigation.navigate('Workout', { screen: 'WorkoutMain' })}
          >
            <Text style={styles.quickActionEmoji}>🏋️</Text>
            <Text style={styles.quickActionText}>Empezar Entrenamiento</Text>
            <Text style={styles.quickActionArrow}>→</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.quickAction}
            onPress={() => navigation.navigate('Nutrition', { screen: 'NutritionMain' })}
          >
            <Text style={styles.quickActionEmoji}>🍽️</Text>
            <Text style={styles.quickActionText}>Registrar Comida</Text>
            <Text style={styles.quickActionArrow}>→</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.quickAction}>
            <Text style={styles.quickActionEmoji}>📊</Text>
            <Text style={styles.quickActionText}>Ver Progreso</Text>
            <Text style={styles.quickActionArrow}>→</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.quickAction}>
            <Text style={styles.quickActionEmoji}>⏱️</Text>
            <Text style={styles.quickActionText}>Cronómetro</Text>
            <Text style={styles.quickActionArrow}>→</Text>
          </TouchableOpacity>
        </View>

        {/* Consejos */}
        <Text style={styles.sectionTitle}>Consejo del Día</Text>

        <View style={styles.tipCard}>
          <Text style={styles.tipTitle}>🥗 Nutrición</Text>
          <Text style={styles.tipText}>
            Recuerda beber al menos 2 litros de agua diariamente. La hidratación es fundamental para el rendimiento en el entrenamiento.
          </Text>
        </View>

        {/* Reto */}
        <Text style={styles.sectionTitle}>Reto de Hoy</Text>

        <View style={styles.challengeCard}>
          <View style={styles.challengeContent}>
            <Text style={styles.challengeEmoji}>🔥</Text>
            <View style={styles.challengeText}>
              <Text style={styles.challengeTitle}>Quemar 500 calorías</Text>
              <Text style={styles.challengeProgress}>0 / 500 cal completadas</Text>
              <View style={styles.progressBar}>
                <View style={[styles.progressFill, { width: '0%' }]} />
              </View>
            </View>
          </View>
        </View>

        {/* Footer spacing */}
        <View style={{ height: 40 }} />
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F7FA'
  },

  header: {
    paddingHorizontal: 16,
    paddingTop: 20,
    paddingBottom: 16
  },

  greeting: {
    fontSize: 28,
    fontWeight: '700',
    color: '#1A1A1A',
    marginBottom: 4
  },

  date: {
    fontSize: 13,
    color: '#666',
    fontWeight: '500'
  },

  card: {
    marginHorizontal: 16,
    marginBottom: 20,
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3
  },

  cardTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#1A1A1A',
    marginBottom: 16
  },

  statsRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center'
  },

  stat: {
    flex: 1,
    alignItems: 'center'
  },

  statValue: {
    fontSize: 22,
    fontWeight: '700',
    color: '#2196F3',
    marginBottom: 4
  },

  statLabel: {
    fontSize: 11,
    color: '#666',
    fontWeight: '500'
  },

  divider: {
    width: 1,
    height: 40,
    backgroundColor: '#E0E0E0'
  },

  motivationCard: {
    marginHorizontal: 16,
    marginBottom: 24,
    backgroundColor: '#FFE66D',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center'
  },

  motivationEmoji: {
    fontSize: 32,
    marginBottom: 8
  },

  motivationText: {
    fontSize: 14,
    color: '#333',
    fontWeight: '500',
    textAlign: 'center',
    lineHeight: 20
  },

  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#1A1A1A',
    paddingHorizontal: 16,
    marginBottom: 12,
    marginTop: 8
  },

  quickActionsContainer: {
    paddingHorizontal: 16,
    marginBottom: 24,
    gap: 10
  },

  quickAction: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2
  },

  quickActionEmoji: {
    fontSize: 24,
    marginRight: 12
  },

  quickActionText: {
    flex: 1,
    fontSize: 14,
    fontWeight: '600',
    color: '#1A1A1A'
  },

  quickActionArrow: {
    fontSize: 18,
    color: '#2196F3',
    fontWeight: '700'
  },

  tipCard: {
    marginHorizontal: 16,
    marginBottom: 20,
    backgroundColor: '#E8F5E9',
    borderLeftWidth: 4,
    borderLeftColor: '#4CAF50',
    borderRadius: 10,
    padding: 14
  },

  tipTitle: {
    fontSize: 13,
    fontWeight: '700',
    color: '#2E7D32',
    marginBottom: 6
  },

  tipText: {
    fontSize: 12,
    color: '#1B5E20',
    lineHeight: 18,
    fontWeight: '500'
  },

  challengeCard: {
    marginHorizontal: 16,
    marginBottom: 24,
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2
  },

  challengeContent: {
    flexDirection: 'row',
    alignItems: 'center'
  },

  challengeEmoji: {
    fontSize: 28,
    marginRight: 12
  },

  challengeText: {
    flex: 1
  },

  challengeTitle: {
    fontSize: 14,
    fontWeight: '700',
    color: '#1A1A1A',
    marginBottom: 4
  },

  challengeProgress: {
    fontSize: 12,
    color: '#666',
    marginBottom: 8,
    fontWeight: '500'
  },

  progressBar: {
    height: 6,
    backgroundColor: '#E0E0E0',
    borderRadius: 3,
    overflow: 'hidden'
  },

  progressFill: {
    height: '100%',
    backgroundColor: '#FF6B6B',
    borderRadius: 3
  }
});

export default HomeScreen;
