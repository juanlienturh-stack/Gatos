import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  Modal,
  FlatList,
  TextInput
} from 'react-native';
import { mealsDatabase, calculateTotalMacros, getMealsByCategory } from './database_meals';

const { width } = Dimensions.get('window');

const NutritionScreen = () => {
  const [selectedMeals, setSelectedMeals] = useState({
    desayuno: null,
    almuerzo: null,
    cena: null
  });

  const [mealModal, setMealModal] = useState({ visible: false, type: '' });
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredMeals, setFilteredMeals] = useState([]);

  // Calcular macros totales
  const getTotalMacros = () => {
    const meals = Object.values(selectedMeals).filter(m => m !== null);
    return calculateTotalMacros(meals);
  };

  const totalMacros = getTotalMacros();

  // Manejar búsqueda
  const handleSearch = (text) => {
    setSearchQuery(text);
    const mealType = mealModal.type;
    const allMeals = mealsDatabase[mealType] || [];

    if (text.trim() === '') {
      setFilteredMeals(allMeals);
    } else {
      setFilteredMeals(
        allMeals.filter(meal =>
          meal.name.toLowerCase().includes(text.toLowerCase())
        )
      );
    }
  };

  // Abrir modal de selección
  const openMealModal = (type) => {
    setMealModal({ visible: true, type });
    setSearchQuery('');
    setFilteredMeals(mealsDatabase[type] || []);
  };

  // Seleccionar comida
  const selectMeal = (meal) => {
    setSelectedMeals({
      ...selectedMeals,
      [mealModal.type]: meal
    });
    setMealModal({ visible: false, type: '' });
    setSearchQuery('');
  };

  // Remover comida
  const removeMeal = (type) => {
    setSelectedMeals({
      ...selectedMeals,
      [type]: null
    });
  };

  // Componente de tarjeta de comida
  const MealCard = ({ meal, type, onPress, onRemove }) => {
    if (!meal) {
      return (
        <TouchableOpacity
          style={styles.emptyMealCard}
          onPress={onPress}
        >
          <Text style={styles.addMealText}>+ Agregar {type}</Text>
        </TouchableOpacity>
      );
    }

    return (
      <View style={styles.mealCard}>
        <View style={styles.mealHeader}>
          <Text style={styles.mealName}>{meal.name}</Text>
          <TouchableOpacity
            onPress={() => onRemove(type)}
            style={styles.removeBtn}
          >
            <Text style={styles.removeBtnText}>✕</Text>
          </TouchableOpacity>
        </View>

        <Text style={styles.mealDescription}>{meal.description}</Text>

        {/* Macros en línea */}
        <View style={styles.macrosRow}>
          <View style={styles.macroItem}>
            <Text style={styles.macroValue}>{meal.calories}</Text>
            <Text style={styles.macroLabel}>Cal</Text>
          </View>
          <View style={styles.macroItem}>
            <Text style={styles.macroValue}>{meal.protein}g</Text>
            <Text style={styles.macroLabel}>Proteína</Text>
          </View>
          <View style={styles.macroItem}>
            <Text style={styles.macroValue}>{meal.carbs}g</Text>
            <Text style={styles.macroLabel}>Carbs</Text>
          </View>
          <View style={styles.macroItem}>
            <Text style={styles.macroValue}>{meal.fat}g</Text>
            <Text style={styles.macroLabel}>Grasas</Text>
          </View>
        </View>

        {/* Nutrientes */}
        <View style={styles.nutrientSection}>
          <Text style={styles.nutrientTitle}>Nutrientes:</Text>
          <View style={styles.nutrientGrid}>
            <View style={styles.nutrientItem}>
              <Text style={styles.nutrientLabel}>Calcio:</Text>
              <Text style={styles.nutrientValue}>{meal.nutrients.calcio}</Text>
            </View>
            <View style={styles.nutrientItem}>
              <Text style={styles.nutrientLabel}>Hierro:</Text>
              <Text style={styles.nutrientValue}>{meal.nutrients.hierro}</Text>
            </View>
            <View style={styles.nutrientItem}>
              <Text style={styles.nutrientLabel}>Fibra:</Text>
              <Text style={styles.nutrientValue}>{meal.fiber}g</Text>
            </View>
          </View>
        </View>

        {/* Cambiar comida */}
        <TouchableOpacity
          style={styles.changeMealBtn}
          onPress={onPress}
        >
          <Text style={styles.changeMealText}>Cambiar</Text>
        </TouchableOpacity>
      </View>
    );
  };

  // Componente de item en lista de selección
  const MealItem = ({ meal }) => (
    <TouchableOpacity
      style={styles.mealListItem}
      onPress={() => selectMeal(meal)}
    >
      <View style={styles.mealListContent}>
        <Text style={styles.mealListName}>{meal.name}</Text>
        <Text style={styles.mealListDesc}>{meal.description}</Text>
        <View style={styles.mealListMacros}>
          <Text style={styles.mealListMacroItem}>{meal.calories} cal</Text>
          <Text style={styles.mealListMacroItem}>P: {meal.protein}g</Text>
          <Text style={styles.mealListMacroItem}>C: {meal.carbs}g</Text>
          <Text style={styles.mealListMacroItem}>G: {meal.fat}g</Text>
        </View>
      </View>
    </TouchableOpacity>
  );

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {/* Encabezado */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Nutrición Diaria</Text>
        <Text style={styles.headerSubtitle}>Desayuno, Almuerzo y Cena</Text>
      </View>

      {/* Resumen de Macros Totales */}
      <View style={styles.summaryCard}>
        <Text style={styles.summaryTitle}>Resumen del Día</Text>

        <View style={styles.macrosSummaryRow}>
          <View style={styles.macrosSummaryItem}>
            <Text style={styles.macrosSummaryValue}>{totalMacros.calories}</Text>
            <Text style={styles.macrosSummaryLabel}>Calorías</Text>
            <View style={[styles.macroBar, { backgroundColor: '#FF6B6B', width: `${(totalMacros.calories / 2500) * 100}%` }]} />
          </View>
          <View style={styles.macrosSummaryItem}>
            <Text style={styles.macrosSummaryValue}>{totalMacros.protein}g</Text>
            <Text style={styles.macrosSummaryLabel}>Proteína</Text>
            <View style={[styles.macroBar, { backgroundColor: '#4ECDC4', width: `${(totalMacros.protein / 200) * 100}%` }]} />
          </View>
          <View style={styles.macrosSummaryItem}>
            <Text style={styles.macrosSummaryValue}>{totalMacros.carbs}g</Text>
            <Text style={styles.macrosSummaryLabel}>Carbs</Text>
            <View style={[styles.macroBar, { backgroundColor: '#FFE66D', width: `${(totalMacros.carbs / 300) * 100}%` }]} />
          </View>
          <View style={styles.macrosSummaryItem}>
            <Text style={styles.macrosSummaryValue}>{totalMacros.fat}g</Text>
            <Text style={styles.macrosSummaryLabel}>Grasas</Text>
            <View style={[styles.macroBar, { backgroundColor: '#95E1D3', width: `${(totalMacros.fat / 100) * 100}%` }]} />
          </View>
        </View>

        {/* Meta Nutricional */}
        <View style={styles.mealGoal}>
          <Text style={styles.mealGoalLabel}>Meta Recomendada:</Text>
          <Text style={styles.mealGoalValue}>2200 Cal | 165g Proteína | 275g Carbs | 73g Grasas</Text>
        </View>
      </View>

      {/* Secciones de Comidas */}
      <View style={styles.mealsContainer}>
        {/* Desayuno */}
        <View style={styles.mealSection}>
          <Text style={styles.sectionTitle}>🌅 Desayuno</Text>
          <MealCard
            meal={selectedMeals.desayuno}
            type="desayuno"
            onPress={() => openMealModal('desayuno')}
            onRemove={removeMeal}
          />
        </View>

        {/* Almuerzo */}
        <View style={styles.mealSection}>
          <Text style={styles.sectionTitle}>🍽️ Almuerzo</Text>
          <MealCard
            meal={selectedMeals.almuerzo}
            type="almuerzo"
            onPress={() => openMealModal('almuerzo')}
            onRemove={removeMeal}
          />
        </View>

        {/* Cena */}
        <View style={styles.mealSection}>
          <Text style={styles.sectionTitle}>🌙 Cena</Text>
          <MealCard
            meal={selectedMeals.cena}
            type="cena"
            onPress={() => openMealModal('cena')}
            onRemove={removeMeal}
          />
        </View>
      </View>

      {/* Botón de Guardar */}
      <TouchableOpacity style={styles.saveButton}>
        <Text style={styles.saveButtonText}>💾 Guardar Plan de Hoy</Text>
      </TouchableOpacity>

      {/* Modal de Selección de Comidas */}
      <Modal
        visible={mealModal.visible}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setMealModal({ visible: false, type: '' })}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContainer}>
            {/* Header */}
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Seleccionar {mealModal.type}</Text>
              <TouchableOpacity
                onPress={() => setMealModal({ visible: false, type: '' })}
                style={styles.modalCloseBtn}
              >
                <Text style={styles.modalCloseBtnText}>✕</Text>
              </TouchableOpacity>
            </View>

            {/* Buscador */}
            <View style={styles.searchContainer}>
              <TextInput
                style={styles.searchInput}
                placeholder={`Buscar ${mealModal.type}...`}
                placeholderTextColor="#999"
                value={searchQuery}
                onChangeText={handleSearch}
              />
            </View>

            {/* Lista de Comidas */}
            <FlatList
              data={filteredMeals}
              keyExtractor={(item) => item.id}
              renderItem={({ item }) => <MealItem meal={item} />}
              scrollEnabled={true}
              nestedScrollEnabled={true}
              contentContainerStyle={styles.mealListContainer}
            />
          </View>
        </View>
      </Modal>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F7FA'
  },

  header: {
    paddingHorizontal: 16,
    paddingTop: 20,
    paddingBottom: 16
  },

  headerTitle: {
    fontSize: 28,
    fontWeight: '700',
    color: '#1A1A1A',
    marginBottom: 4
  },

  headerSubtitle: {
    fontSize: 14,
    color: '#666',
    fontWeight: '500'
  },

  // Resumen de Macros
  summaryCard: {
    marginHorizontal: 16,
    marginBottom: 24,
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3
  },

  summaryTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1A1A1A',
    marginBottom: 16
  },

  macrosSummaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16
  },

  macrosSummaryItem: {
    flex: 1,
    marginHorizontal: 4
  },

  macrosSummaryValue: {
    fontSize: 16,
    fontWeight: '700',
    color: '#1A1A1A',
    marginBottom: 4
  },

  macrosSummaryLabel: {
    fontSize: 11,
    color: '#666',
    fontWeight: '500',
    marginBottom: 6
  },

  macroBar: {
    height: 4,
    borderRadius: 2,
    backgroundColor: '#E0E0E0'
  },

  mealGoal: {
    backgroundColor: '#F0F8FF',
    borderLeftWidth: 4,
    borderLeftColor: '#2196F3',
    paddingLeft: 12,
    paddingVertical: 12,
    borderRadius: 8
  },

  mealGoalLabel: {
    fontSize: 12,
    color: '#666',
    fontWeight: '500',
    marginBottom: 4
  },

  mealGoalValue: {
    fontSize: 13,
    color: '#2196F3',
    fontWeight: '600'
  },

  mealsContainer: {
    paddingHorizontal: 16
  },

  mealSection: {
    marginBottom: 24
  },

  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1A1A1A',
    marginBottom: 12
  },

  // Tarjeta de Comida
  emptyMealCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    borderWidth: 2,
    borderStyle: 'dashed',
    borderColor: '#DDD',
    paddingVertical: 40,
    alignItems: 'center',
    justifyContent: 'center'
  },

  addMealText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#2196F3'
  },

  mealCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2
  },

  mealHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 8
  },

  mealName: {
    fontSize: 16,
    fontWeight: '700',
    color: '#1A1A1A',
    flex: 1
  },

  removeBtn: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: '#FFE0E0',
    alignItems: 'center',
    justifyContent: 'center'
  },

  removeBtnText: {
    fontSize: 18,
    color: '#FF6B6B',
    fontWeight: '700'
  },

  mealDescription: {
    fontSize: 12,
    color: '#666',
    marginBottom: 12,
    fontStyle: 'italic'
  },

  macrosRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    backgroundColor: '#F5F7FA',
    borderRadius: 10,
    paddingVertical: 12,
    marginBottom: 12
  },

  macroItem: {
    alignItems: 'center'
  },

  macroValue: {
    fontSize: 14,
    fontWeight: '700',
    color: '#1A1A1A'
  },

  macroLabel: {
    fontSize: 10,
    color: '#666',
    marginTop: 2
  },

  nutrientSection: {
    backgroundColor: '#F9FFF9',
    borderLeftWidth: 3,
    borderLeftColor: '#4CAF50',
    padding: 10,
    borderRadius: 8,
    marginBottom: 12
  },

  nutrientTitle: {
    fontSize: 12,
    fontWeight: '600',
    color: '#4CAF50',
    marginBottom: 8
  },

  nutrientGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between'
  },

  nutrientItem: {
    flex: 1
  },

  nutrientLabel: {
    fontSize: 10,
    color: '#666',
    fontWeight: '500'
  },

  nutrientValue: {
    fontSize: 12,
    color: '#1A1A1A',
    fontWeight: '600',
    marginTop: 2
  },

  changeMealBtn: {
    backgroundColor: '#E3F2FD',
    paddingVertical: 10,
    borderRadius: 8,
    alignItems: 'center'
  },

  changeMealText: {
    fontSize: 13,
    color: '#2196F3',
    fontWeight: '600'
  },

  saveButton: {
    marginHorizontal: 16,
    marginVertical: 24,
    backgroundColor: '#4CAF50',
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
    shadowColor: '#4CAF50',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 5
  },

  saveButtonText: {
    fontSize: 16,
    fontWeight: '700',
    color: '#FFFFFF'
  },

  // Modal Styles
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)'
  },

  modalContainer: {
    flex: 1,
    marginTop: 50,
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20
  },

  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0'
  },

  modalTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#1A1A1A',
    textTransform: 'capitalize'
  },

  modalCloseBtn: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#F0F0F0',
    alignItems: 'center',
    justifyContent: 'center'
  },

  modalCloseBtnText: {
    fontSize: 18,
    color: '#1A1A1A',
    fontWeight: '700'
  },

  searchContainer: {
    paddingHorizontal: 16,
    paddingVertical: 12
  },

  searchInput: {
    backgroundColor: '#F5F7FA',
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 14,
    color: '#1A1A1A',
    borderWidth: 1,
    borderColor: '#E0E0E0'
  },

  mealListContainer: {
    paddingHorizontal: 16,
    paddingBottom: 20
  },

  mealListItem: {
    backgroundColor: '#F5F7FA',
    borderRadius: 10,
    padding: 12,
    marginBottom: 10,
    borderLeftWidth: 4,
    borderLeftColor: '#2196F3'
  },

  mealListContent: {
    flex: 1
  },

  mealListName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#1A1A1A',
    marginBottom: 4
  },

  mealListDesc: {
    fontSize: 12,
    color: '#666',
    marginBottom: 8
  },

  mealListMacros: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8
  },

  mealListMacroItem: {
    fontSize: 10,
    color: '#555',
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    fontWeight: '500'
  }
});

export default NutritionScreen;
