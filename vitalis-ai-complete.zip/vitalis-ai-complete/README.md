# 🚀 VITALIS AI - APLICACIÓN COMPLETA LISTA PARA USAR

## ¿QUÉ ES ESTO?

Una **aplicación móvil completa** de fitness con:
- ✅ **Pantalla de Inicio** - Dashboard diario
- ✅ **Pantalla de Entrenamiento** - 39 ejercicios en 7 categorías
- ✅ **Pantalla de Nutrición** - 44 comidas con macros completos
- ✅ **Pantalla de Perfil** - Gestión de datos personales
- ✅ **Navegación automática** - Entre todas las pantallas

---

## 📱 INSTALACIÓN (1 minuto)

### Opción 1: Usando Expo (RECOMENDADO)

```bash
# 1. Instala Expo CLI globalmente (si no lo tienes)
npm install -g expo-cli

# 2. Entra a la carpeta del proyecto
cd vitalis-ai-complete

# 3. Instala dependencias
npm install

# 4. Inicia la app
npm start

# 5. Escanea el código QR con tu teléfono
#    - iOS: Usa la cámara o la app de Expo
#    - Android: Usa la app de Expo Go

```

### Opción 2: Para Android

```bash
npm start
# Luego presiona 'a' en la terminal
```

### Opción 3: Para iOS

```bash
npm start
# Luego presiona 'i' en la terminal
```

---

## 🎯 PANTALLA POR PANTALLA

### 1️⃣ **INICIO** (🏠 Tab)

#### ¿QUÉ VES?
```
┌─────────────────────────────┐
│  ¡Hola, Usuario! 👋         │
│  11 de Marzo, 2026          │
├─────────────────────────────┤
│  📊 HOY                     │
│  0 Entrenamientos           │
│  0 Comidas                  │
│  0 Calorías                 │
├─────────────────────────────┤
│  💪 "Tu cuerpo es tu       │
│     templo..."              │
├─────────────────────────────┤
│  ACCIONES RÁPIDAS:          │
│  🏋️ Empezar Entrenamiento  │
│  🍽️ Registrar Comida       │
│  📊 Ver Progreso            │
│  ⏱️ Cronómetro             │
├─────────────────────────────┤
│  🔥 RETO DE HOY             │
│  Quemar 500 calorías        │
│  0 / 500 cal completadas    │
└─────────────────────────────┘
```

#### ¿QUÉ PUEDES HACER?
- ✅ Ver resumen del día
- ✅ Ver motivación diaria
- ✅ Ir al entrenamiento
- ✅ Ir a nutrición
- ✅ Ver progreso del reto

---

### 2️⃣ **ENTRENAMIENTO** (🏋️ Tab)

#### ¿QUÉ VES?
```
┌─────────────────────────────┐
│ Mi Entrenamiento            │
│ Selecciona ejercicios...    │
├─────────────────────────────┤
│ GRUPOS MUSCULARES:          │
│ 🏋️ PECHO  🔙 ESPALDA      │
│ 🦵 PIERNAS  💪 HOMBROS    │
│ 💯 BRAZOS  ⭐ CORE        │
│ 🏃 CARDIO                   │
├─────────────────────────────┤
│ [+ Agregar Ejercicio (5)]   │
├─────────────────────────────┤
│ TU PLAN:                    │
│ 🏋️ Press de Banca          │
│    Completo: 2/4 [50%]     │
│    [-] [+] [✓ Todo]        │
└─────────────────────────────┘
```

#### ¿CÓMO FUNCIONA?

**PASO 1: Selecciona un grupo muscular**
```
Haz clic en: 🏋️ PECHO
```

**PASO 2: Se abre un modal con ejercicios**
```
EJERCICIOS PARA PECHO:
├─ Press de Banca (Intermedio, 4 series)
├─ Flexiones (Principiante, 3 series)
├─ Aperturas (Intermedio, 3 series)
└─ ... más ejercicios
```

**PASO 3: Haz clic en un ejercicio**
```
Se abre la vista detallada:
- Nombre
- Dificultad
- Descripción
- Series y reps
- Calorías a quemar
- Botón: [+ AGREGAR A MI PLAN]
```

**PASO 4: Se agrega a tu plan**
```
Verás una tarjeta con:
- Nombre del ejercicio
- Información
- Contador de series: 0/4
- Botones: [-] [+] [✓ Todo]
```

**PASO 5: Rastrear progreso**
```
Mientras entrenas:
1. Termina serie 1 → Presiona [+]
2. Termina serie 2 → Presiona [+]
3. Termina serie 3 → Presiona [+]
4. Termina serie 4 → Presiona [+]
                      ↓
                    [100%] ✓ HECHO

O simplemente presiona [✓ Todo] al final
```

**PASO 6: Guarda tu entrenamiento**
```
Presiona: [💾 GUARDAR ENTRENAMIENTO]
✅ Entrenamiento guardado exitosamente
```

#### 📊 CARACTERÍSTICAS
- 39 ejercicios totales
- 7 grupos musculares
- Información completa de cada uno
- Sistema de progreso visual
- Resumen automático en vivo

---

### 3️⃣ **NUTRICIÓN** (🍽️ Tab)

#### ¿QUÉ VES?
```
┌─────────────────────────────┐
│ Nutrición Diaria            │
│ Desayuno, Almuerzo y Cena   │
├─────────────────────────────┤
│ RESUMEN DEL DÍA:            │
│ Calorías: 1500/2200 [68%]   │
│ Proteína: 95g/165g [58%]    │
│ Carbs: 150g/275g [55%]      │
│ Grasas: 35g/73g [48%]       │
├─────────────────────────────┤
│ 🌅 DESAYUNO                 │
│ [+ Agregar Desayuno]        │
├─────────────────────────────┤
│ 🍽️ ALMUERZO                │
│ [+ Agregar Almuerzo]        │
├─────────────────────────────┤
│ 🌙 CENA                     │
│ [+ Agregar Cena]            │
└─────────────────────────────┘
```

#### ¿CÓMO FUNCIONA?

**PASO 1: Presiona "+ Agregar Desayuno"**

**PASO 2: Se abre modal con comidas**
```
SELECCIONAR DESAYUNO:
🔍 [Buscar desayuno...]

├─ Huevos con Pan Tostado
│  350 cal | P:18g C:35g G:12g
├─ Avena con Frutas
│  320 cal | P:10g C:55g G:8g
├─ Yogur con Granola
│  380 cal | P:15g C:52g G:10g
└─ ... más opciones
```

**PASO 3: Haz clic en la comida que quieras**
```
Se agregará automáticamente y verás:

HUEVOS CON PAN TOSTADO
"2 huevos + 2 rebanadas"

MACROS:
350 Cal | 18g P | 35g C | 12g G

NUTRIENTES:
Calcio: 80mg | Hierro: 3.5mg
Vitamina A: 650IU
Vitamina C: 0mg

[Cambiar] [✕ Eliminar]
```

**PASO 4: Repite para Almuerzo y Cena**

**PASO 5: Ve el resumen automático**
```
Arriba se actualiza automáticamente:
Calorías: 1500/2200  68% ✓
Proteína: 95g/165g   58% ✓
Carbs: 150g/275g     55% ✓
Grasas: 35g/73g      48% ✓
```

**PASO 6: Guarda tu plan**
```
Presiona: [💾 GUARDAR PLAN DE HOY]
✅ Plan guardado exitosamente
```

#### 📊 CARACTERÍSTICAS
- 44 comidas totales
- Desayuno, Almuerzo, Cena separados
- Macros completos (proteína, carbs, grasas, fibra)
- Nutrientes detallados (calcio, hierro, vitaminas)
- Búsqueda en tiempo real
- Resumen automático del día

---

### 4️⃣ **PERFIL** (👤 Tab)

#### ¿QUÉ VES?
```
┌─────────────────────────────┐
│ Mi Perfil                   │
├─────────────────────────────┤
│          👤                 │
│      Usuario                │
│  usuario@example.com        │
├─────────────────────────────┤
│ 📋 INFORMACIÓN PERSONAL:    │
│ Edad: 25 años               │
│ Peso: 75 kg                 │
│ Altura: 180 cm              │
│ [✏️ Editar]                │
├─────────────────────────────┤
│ 📊 IMC: 23.1 (Normal)      │
├─────────────────────────────┤
│ 🎯 OBJETIVO DE FITNESS      │
│ ⬇️ Perder Peso             │
│ ➡️ Mantener (Seleccionado)  │
│ ⬆️ Ganar Músculo            │
├─────────────────────────────┤
│ 💡 RECOMENDACIONES          │
│ Calorías: 2200 kcal/día     │
│ Proteína: 120-165g/día      │
│ Agua: 2250ml/día            │
└─────────────────────────────┘
```

#### ¿QUÉ PUEDES HACER?
- ✅ Ver tu información personal
- ✅ Editar tu perfil
- ✅ Ver tu IMC
- ✅ Cambiar objetivo de fitness
- ✅ Ver recomendaciones personalizadas
- ✅ Cerrar sesión

#### ¿CÓMO EDITAR TU PERFIL?

1. Presiona **[✏️ Editar]**
2. Cambia los valores:
   - Nombre
   - Edad
   - Peso
   - Altura
3. Presiona **[✓ Guardar]**
4. Tu perfil se actualiza automáticamente

---

## 🎮 EJEMPLO: UN DÍA COMPLETO

### MAÑANA - ENTRENAMIENTO

```
1️⃣ Abre la app
   ↓
2️⃣ Ve a TAB: 🏋️ ENTRENAMIENTO
   ↓
3️⃣ Presiona botón: 🏋️ PECHO
   ↓
4️⃣ Se abre modal con ejercicios del pecho
   ↓
5️⃣ Haz clic en: "Press de Banca"
   ↓
6️⃣ Se abre vista detallada
   ↓
7️⃣ Presiona: [+ AGREGAR A MI PLAN]
   ↓
8️⃣ Se agrega a tu plan de entrenamiento
   ↓
9️⃣ Repite pasos 3-8 para más ejercicios
   ↓
🔟 Mientras entrenas, presiona [+] para cada serie completada
   ↓
1️⃣1️⃣ Cuando termines todo, presiona [💾 GUARDAR ENTRENAMIENTO]
```

### MEDIO DÍA - NUTRICIÓN

```
1️⃣ Ve a TAB: 🍽️ NUTRICIÓN
   ↓
2️⃣ Presiona: [+ Agregar Desayuno]
   ↓
3️⃣ Se abre modal con opciones
   ↓
4️⃣ Busca o selecciona una comida
   ↓
5️⃣ Haz clic en ella
   ↓
6️⃣ Se agrega y ves macros automáticamente
   ↓
7️⃣ Repite para Almuerzo y Cena
   ↓
8️⃣ Arriba ves el resumen en vivo
   ↓
9️⃣ Presiona [💾 GUARDAR PLAN DE HOY]
```

### NOCHE - PERFIL

```
1️⃣ Ve a TAB: 👤 PERFIL
   ↓
2️⃣ Ve tu información
   ↓
3️⃣ Si quieres cambiar algo, presiona [✏️ Editar]
   ↓
4️⃣ Modifica los valores
   ↓
5️⃣ Presiona [✓ Guardar]
```

---

## 🎨 COLORES Y DISEÑO

```
Fondo principal: #F5F7FA (Gris muy claro)
Tarjetas: #FFFFFF (Blanco)
Texto principal: #1A1A1A (Gris oscuro)
Primario: #2196F3 (Azul)
Éxito: #4CAF50 (Verde)
Advertencia: #FFE66D (Amarillo)
Error: #FF6B6B (Rojo)
```

---

## 💾 ALMACENAMIENTO

Actualmente todo se guarda en la **memoria del teléfono**.

Para guardar en la nube (Firebase), necesitarás:
1. Crear cuenta en Firebase
2. Configurar el proyecto
3. Integrar las funciones (ver EJEMPLOS_INTEGRACION.js en outputs)

---

## 🚀 PRÓXIMAS FUNCIONALIDADES

- Sincronización con Firebase
- Gráficos de progreso
- Historial de entrenamientos
- Notificaciones recordatorios
- Análisis de datos
- Integración con wearables
- Comunidad social

---

## 📁 ESTRUCTURA DE CARPETAS

```
vitalis-ai-complete/
├── App.js                    ← App principal
├── app.json                  ← Config Expo
├── package.json              ← Dependencias
├── src/
│   ├── database_exercises.js ← 39 ejercicios
│   ├── database_meals.js     ← 44 comidas
│   └── screens/
│       ├── HomeScreen.js     ← Inicio
│       ├── WorkoutScreen.js  ← Entrenamiento
│       ├── NutritionScreen.js ← Nutrición
│       └── ProfileScreen.js  ← Perfil
└── assets/                   ← Imágenes (opcional)
```

---

## ❓ PREGUNTAS FRECUENTES

### ¿Necesito Android Studio?
No, con Expo CLI es suficiente.

### ¿Necesito un teléfono?
Puedes usar emulador Android o Simulator iOS.

### ¿Dónde se guardan mis datos?
En tu teléfono (AsyncStorage). Opcionalmente en Firebase.

### ¿Puedo cambiar los colores?
Sí, están en StyleSheet.create() en cada pantalla.

### ¿Puedo agregar más ejercicios?
Sí, edita database_exercises.js

### ¿Puedo agregar más comidas?
Sí, edita database_meals.js

### ¿Funciona sin internet?
Sí, todo funciona offline.

---

## 🎉 ¡LISTO!

Tu aplicación está **100% funcional** y lista para usar.

**Próximo paso:** 
```bash
npm install
npm start
```

Escanea el QR y ¡disfruta! 💪🚀

---

*Creada: 11 de Marzo de 2026*
*Versión: 1.0 Completa*
*Estado: ✅ LISTA PARA PRODUCCIÓN*
